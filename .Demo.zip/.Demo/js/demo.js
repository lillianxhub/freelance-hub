const appState = { timerRunning: true, elapsed: 6138, toastTimer: null };

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

function formatTimer(totalSeconds) {
  const hours = String(Math.floor(totalSeconds / 3600)).padStart(2, '0');
  const minutes = String(Math.floor((totalSeconds % 3600) / 60)).padStart(2, '0');
  const seconds = String(totalSeconds % 60).padStart(2, '0');
  return `${hours}:${minutes}:${seconds}`;
}

function syncTimer() {
  const value = formatTimer(appState.elapsed);
  ['#timerDisplay', '#bigTimerDisplay'].forEach((selector) => {
    const element = $(selector);
    if (element) element.textContent = value;
  });
  $$('#timerToggle, #bigTimerToggle').forEach((button) => {
    button.innerHTML = appState.timerRunning
      ? '<span class="stop-square"></span> Stop timer'
      : '<span>▶</span> Resume timer';
    button.classList.toggle('button-stop', appState.timerRunning);
  });
}

function toggleTimer() {
  appState.timerRunning = !appState.timerRunning;
  syncTimer();
  showToast(appState.timerRunning ? 'Timer resumed' : 'Time entry saved to Website redesign');
}

function navigate(viewName) {
  const view = viewName || 'overview';
  $$('.view').forEach((section) => section.classList.toggle('active', section.id === `${view}-view`));
  $$('.nav-item').forEach((item) => item.classList.toggle('active', item.dataset.view === view));
  const labels = { overview: 'Overview', projects: 'Projects', tracker: 'Time tracker', clients: 'Clients', reports: 'Reports', settings: 'Settings' };
  $('#currentViewLabel').textContent = labels[view] || 'Overview';
  $('#sidebar').classList.remove('open');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function showToast(message) {
  const toast = $('#toast');
  $('#toastMessage').textContent = message;
  toast.classList.add('show');
  clearTimeout(appState.toastTimer);
  appState.toastTimer = setTimeout(() => toast.classList.remove('show'), 2800);
}

function openModal(type = 'project') {
  const modal = $('#modalBackdrop');
  const title = $('#modalTitle');
  const copy = $('#modalCopy');
  const eyebrow = $('#modalEyebrow');
  const nameInput = document.querySelector('input[name="name"]');
  const form = $('#demoForm');
  if (type === 'manual') {
    eyebrow.textContent = 'Time tracker';
    title.textContent = 'Add time entry';
    copy.textContent = 'Log work you completed outside the live timer.';
    nameInput.placeholder = 'e.g. Client feedback session';
  } else if (type === 'client') {
    eyebrow.textContent = 'Workspace';
    title.textContent = 'Add client';
    copy.textContent = 'Save client details for projects and activity.';
    nameInput.placeholder = 'e.g. Acme Corporation';
  } else {
    eyebrow.textContent = 'Workspace';
    title.textContent = 'New project';
    copy.textContent = 'Create a project to start tracking work and tasks.';
    nameInput.placeholder = 'e.g. Product launch website';
  }
  form.dataset.mode = type;
  modal.classList.add('open');
  modal.setAttribute('aria-hidden', 'false');
  setTimeout(() => nameInput.focus(), 100);
}

function closeModal() {
  $('#modalBackdrop').classList.remove('open');
  $('#modalBackdrop').setAttribute('aria-hidden', 'true');
}

$$('.nav-item, [data-view]').forEach((element) => element.addEventListener('click', () => navigate(element.dataset.view)));
$('#mobileMenu').addEventListener('click', () => $('#sidebar').classList.toggle('open'));
$('#timerToggle').addEventListener('click', toggleTimer);
$('#bigTimerToggle').addEventListener('click', toggleTimer);
$('#newProjectButton').addEventListener('click', () => openModal('project'));
$('#newProjectButtonAlt').addEventListener('click', () => openModal('project'));
$('#manualEntryButton').addEventListener('click', () => openModal('manual'));
$('#manualEntryButtonAlt').addEventListener('click', () => openModal('manual'));
$('#newClientButton').addEventListener('click', () => openModal('client'));
$('#modalClose').addEventListener('click', closeModal);
$('#modalBackdrop').addEventListener('click', (event) => { if (event.target === $('#modalBackdrop')) closeModal(); });
$('#demoForm').addEventListener('submit', (event) => {
  event.preventDefault();
  const mode = event.currentTarget.dataset.mode;
  const messages = { project: 'Project created in demo workspace', manual: 'Time entry added to your week', client: 'Client added to your workspace' };
  closeModal();
  event.currentTarget.reset();
  showToast(messages[mode] || 'Saved in demo workspace');
});
$('#exportButton').addEventListener('click', () => showToast('Report export is ready in the full app'));
$('#learnMoreButton').addEventListener('click', () => showToast('The full version connects this workspace to your account'));
$('#periodButton').addEventListener('click', () => showToast('Date range selector opened'));
document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeModal(); });

syncTimer();
setInterval(() => { if (appState.timerRunning) { appState.elapsed += 1; syncTimer(); } }, 1000);
